insert into department(id,name) values(1,'admin');
insert into department(id,name) values(2,'finance');
