alter table employee add department_id int ;
alter table employee add constraint fk foreign key (department_id) references department(id) ;
