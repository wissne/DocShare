create table department(
	id int not null,
	name varchar(30) not null
);
create table employee(
	id int not null,
	name varchar(100) not null
);


